# WebProgrammingProject
Simple Web application Project by using ajax and servlet and mysql and sending a text message usng a third party twillio
